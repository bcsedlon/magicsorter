=======
Credits
=======

Development Lead
----------------

* Jonas Berg <pyhys@users.sourceforge.net>

Contributors
------------

Significant contributions by Angelo Compagnucci, Aaron LaLonde, Asier Abalos, 
Simon Funke, Edwin van den Oetelaar, Dominik Socha, Luca Di Gregorio, Dino, 
Peter and Michael Penza.

